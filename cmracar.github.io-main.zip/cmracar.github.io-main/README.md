#### Cemre Acar's personal page website repository.

If you are looking for how to deploy the NextJS project on GitHub pages, 
you can take a look here → <a href="https://medium.com/@cmracar" target="_blank" rel="noreferrer">
    Medium Article
  </a>
